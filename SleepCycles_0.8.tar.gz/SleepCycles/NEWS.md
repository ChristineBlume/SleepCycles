The SleepCycles package
================

<!-- NEWS.md is generated from NEWS.Rmd. Please edit that file -->

## News

### SleepCycles 0.8 (2020-18-11)

First NEWS update. All changes will be documented in this file from now
on.
